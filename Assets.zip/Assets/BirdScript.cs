using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdScript : MonoBehaviour
{
    public Sprite eagle1;
    public Sprite eagle2;
    
    public float flapStrength;

    private SpriteRenderer sr;
    private Rigidbody2D rb;

    // Start is called before the first frame update
    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) == true)
        {
            rb.velocity = Vector2.up * flapStrength;
        }

        if (rb.velocity.y > 0)
        {
            sr.sprite = eagle2;
        }

        else
        {
            sr.sprite = eagle1;
        }

        if (eagle1 == null || eagle2 == null)
        {
            Debug.LogError("Eagle sprites not loaded");
        }
    }
}
